import React from 'react';
import './Contact.css'; // Estilos específicos para Contact

const Contact = () => {
  return (
    <div className="container contact-container">
      <h2>Contacto</h2>
      <form className="form-container">
        <label>
          Nombre:
          <input type="text" />
        </label>
        <br />
        <label>
          Apellido:
          <input type="text" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" />
        </label>
        <br />
        <label>
          Edad:
          <input type="number" />
        </label>
        <br />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
};

export default Contact;
