import React from 'react';
import { Link } from 'react-router-dom';
import Personas from './Personas';
import './Home.css'; // Estilos específicos para Home

const Home = () => {
  return (
    <div className="container home-container">
      <h2>Listado de Personas</h2>
      <ul>
        {Personas.map(person => (
          <li key={person.id}>
            <Link to={`/person/${person.id}`}>{person.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;
