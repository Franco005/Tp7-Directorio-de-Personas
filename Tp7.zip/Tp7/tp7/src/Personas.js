const Personas = [
    {
      id: 1,
      name: 'Juan Pérez',
      age: 28,
      email: 'juan@example.com',
    },
    {
      id: 2,
      name: 'María González',
      age: 40,
      email: 'maria@example.com',
    },
    {
      id: 3,
      name: 'Carlos Sánchez',
      age: 22,
      email: 'carlos@example.com',
    },  ];
  
  export default Personas;
  